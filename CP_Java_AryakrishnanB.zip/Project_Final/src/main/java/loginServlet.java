

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

class getconnection
{
	public boolean check;
	public void connect(String username,String password)
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select password from users where username='"+username+"';");
			if(rs.next())
			{
			if(rs.getString(1).equals(password))
			{
				check=true;
			}
			else
			{
				check=false;
			}
			
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
}



//@WebServlet("/loginServlet")
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		javax.servlet.http.HttpSession session1=request.getSession(false);
		if(session1!=null)
		{
			out.print("<html><script>alert('Already logged in!')</script></html>");
			request.getRequestDispatcher("cart.html").include(request, response);
		}
		else
		{
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		
		getconnection connection=new getconnection();
		connection.connect(username, password);
		if(connection.check==true)
		{
			javax.servlet.http.HttpSession session=request.getSession();
			session.setAttribute("username", username);
			request.getRequestDispatcher("cards.html").include(request, response);
			
		}
		else
		{
			out.print("<html><script>alert('Incorrect credentials.Please try again!')</script></html>");
			javax.servlet.RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
			
		}
	}
		out.close();
		
	}

}
