

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;


class insertinto
{
	public boolean check;
	public void insert(String username,String item,double price,int quantity,double totalprice,String image, String code)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			
			PreparedStatement ps=con.prepareStatement("insert into cart(username,item,price,quantity,totalprice,image,code) values(?,?,?,?,?,?,?)");
			ps.setString(1, username);
			ps.setString(2, item);
			ps.setDouble(3, price);
			ps.setInt(4, quantity);
			ps.setDouble(5, totalprice);
			ps.setString(6, image);
			ps.setString(7, code);
			ps.executeUpdate();
			check=true;
			
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	
	
	
	public double getPrice(String item)
	{
		double price=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select price from items where item='"+item+"';");
			if(rs.next())
			{
				price=rs.getDouble(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return price;
	}
	public String getImage(String item)
	{
		String image="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select image from items where item='"+item+"';");
			if(rs.next())
			{
				image=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return image;
	}
	public String getCode(String item)
	{
		String code="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select code from items where item='"+item+"';");
			if(rs.next())
			{
				code=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return code;
	}

}


//@WebServlet("/insertintoCart")
public class insertintoCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		request.getRequestDispatcher("index.html").include(request, response);
		
		javax.servlet.http.HttpSession session=request.getSession(false);
		if(session!=null)
		{
			String username=(String) session.getAttribute("username");

			String item=null;
			item=request.getParameter("item");
			if(item==null)
			{
			javax.servlet.http.Cookie cookies[]=request.getCookies();
			for(javax.servlet.http.Cookie c:cookies)
			{
				if(c.getName().equals("item"))
				{
					item=c.getValue();
				}
			}
			
			}
			int quantity=Integer.parseInt(request.getParameter("quantity"));
			insertinto add=new insertinto();
			double price=add.getPrice(item);
			String image=add.getImage(item);
			String code=add.getCode(item);
			double totalprice=quantity*price;
			add.insert(username, item,price,quantity, totalprice,image,code);
			if(add.check==true)
			{
				out.print("<br>Successfully added to cart...");
				RequestDispatcher rd=request.getRequestDispatcher("showCart");
				rd.forward(request, response);
				
			}
			else
			{			
				out.print("<br>Error!<br>Try again");
				RequestDispatcher rd=request.getRequestDispatcher("cart.html");
				rd.forward(request, response);
			}
	
		}
		else
		{
			out.print("<html><script>alert('Please log in!')</script></html>");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
		
		out.close();
		
		
	}

}
