

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;

class addinto
{
	public boolean check;
	public void insert(String username, String item,double price,int quantity,double totalprice,String image,String code)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");	
			Statement stmt=con.createStatement();
			
			PreparedStatement ps=con.prepareStatement("insert into orders(username,item,price,quantity,date,totalprice,image,code) values(?,?,?,?,?,?,?,?);");
			ps.setString(1, username);
			ps.setString(2, item);
			ps.setDouble(3, price);
			ps.setInt(4, quantity);
			ps.setString(5, "2021-11-01");
			ps.setDouble(6, totalprice);
			ps.setString(7, image);
			ps.setString(8, code);
			ps.executeUpdate();
			check=true;
			
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
	
	
	public double getPrice(String item)
	{
		double price=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select price from items where item='"+item+"';");
			if(rs.next())
			{
				price=rs.getDouble(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return price;
	}
	public String getImage(String item)
	{
		String image="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select image from items where item='"+item+"';");
			if(rs.next())
			{
				image=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return image;
	}
	public String getCode(String item)
	{
		String code="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select code from items where item='"+item+"';");
			if(rs.next())
			{
				code=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return code;
	}
}


//@WebServlet("/addOrder")
public class addOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		request.getRequestDispatcher("index.html").include(request, response);
		
		
		HttpSession session=request.getSession(false);
		if(session!=null)
		{
			String username=(String) session.getAttribute("username");
			addinto add=new addinto();
			
			String item=null;
			item=request.getParameter("item");
			if(item==null)
			{
			Cookie cookies[]=request.getCookies();
			for(Cookie c:cookies)
			{
				if(c.getName().equals("item"))
				{
					item=c.getValue();
				}
			}
			}
			int quantity=Integer.parseInt(request.getParameter("quantity"));
			double price=add.getPrice(item);
			double totalprice=price*quantity;
			String image=add.getImage(item);
			String code=add.getCode(item);
			add.insert(username,item,price,quantity,totalprice,image,code);
		
			if(add.check==true)
			{
				out.print("Order placed successfully....");
				RequestDispatcher rd=request.getRequestDispatcher("showOrders");
				rd.forward(request, response);
			}
			else
			{
				out.print("Error..<br><br>Please try again!");
				RequestDispatcher rd=request.getRequestDispatcher("cart.html");
				rd.forward(request, response);
			}
		
		}
		else
		{
			out.print("<html><script>alert('Please log in!')</script></html>");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
		
		out.close();
		
		
		
	}

}
