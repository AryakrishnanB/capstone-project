

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


class getDetails
{
	public double getPrice(String item)
	{
		double price=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select price from items where item='"+item+"';");
			if(rs.next())
			{
				price=rs.getDouble(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return price;
	}
	public String getImage(String item)
	{
		String image="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select image from items where item='"+item+"';");
			if(rs.next())
			{
				image=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return image;
	}
	public String getCode(String item)
	{
		String code="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select code from items where item='"+item+"';");
			if(rs.next())
			{
				code=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return code;
	}

}





//@WebServlet("/cartDeleteCookie")
public class cartDeleteCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out=response.getWriter();

		String item=request.getParameter("item");
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		
		Cookie cookie1=new Cookie("item",item+"");
		response.addCookie(cookie1);
		Cookie cookie2=new Cookie("quantity",quantity+"");
		response.addCookie(cookie2);
		
		getDetails details=new getDetails();
		double price=details.getPrice(item);
		String image=details.getImage(item);
		String code=details.getCode(item);
		
		request.getRequestDispatcher("index.html").include(request, response);
		out.print("<center><div style='width:500px; height:300px; text-align:center; padding:20px'><b>Product Details</b><br><br><img src='"+image+"' width='200px' height='200px'><br>Product: "
				+ ""+item+"<br>Product Code: "+code+"<br>Price: "+price+"<br>Quantity: "
						+ ""+quantity+"</center><br><br>");
//		response.sendRedirect("areyousurecart.html");
		request.getRequestDispatcher("areyousurecart.html").include(request, response);
		
		
	}

}
