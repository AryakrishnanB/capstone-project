

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


class orderDetails
{
	public String getItem(int oid)
	{
		String item="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select item from items where order_id="+oid+";");
			if(rs.next())
			{
				item=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return item;
	}
	
	
	public double getPrice(int oid)
	{
		double price=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select price from items where order_id="+oid+";");
			if(rs.next())
			{
				price=rs.getDouble(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return price;
	}
	
	public int getQuantity(int oid)
	{
		int quantity=0;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select quantity from items where order_id="+oid+";");
			if(rs.next())
			{
				quantity=rs.getInt(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return quantity;
	}
	
	public String getImage(int oid)
	{
		String image="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select image from items where order_id="+oid+";");
			if(rs.next())
			{
				image=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return image;
	}
	public String getCode(int oid)
	{
		String code="";
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			Statement stmt=con.createStatement();
			
			ResultSet rs=stmt.executeQuery("select code from items where order_id="+oid+";");
			if(rs.next())
			{
				code=rs.getString(1);
			}
			else
			{
				System.out.println("No such item found...");
			}
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return code;
	}

}



//@WebServlet("/orderDeleteCookie")
public class orderDeleteCookie extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
//		String oid=request.getParameter("oid");
//		
//		Cookie cookie=new Cookie("oid",oid+"");
//		response.addCookie(cookie);
//		response.sendRedirect("cancelOrderID");
//		
		PrintWriter out=response.getWriter();

		int oid=Integer.parseInt(request.getParameter("oid"));
		
		Cookie cookie1=new Cookie("oid",oid+"");
		response.addCookie(cookie1);		
		
		orderDetails details=new orderDetails();
		String item=details.getItem(oid);
		double price=details.getPrice(oid);
		String image=details.getImage(oid);
		String code=details.getCode(oid);
		int quantity=details.getQuantity(oid);
		
		request.getRequestDispatcher("index.html").include(request, response);
		out.print("<center><div style='width:=500px; height:300px;text-align:center; padding:20px;'><b>Product Details</b><br><br><img src='"+image+"'><br>Order ID: "+oid+"<br>Product: "
				+ ""+item+"<br>Product Code: "+code+"<br>Price: "+price+"<br>Quantity: "
						+ ""+quantity+"</center><br><br>");
//		response.sendRedirect("areyousureorder.html");
//		RequestDispatcher rd=request.getRequestDispatcher("areyousureorder.html");
//		rd.forward(request, response);
		request.getRequestDispatcher("areyousureorder.html").include(request, response);
		
		
		
	}

}
