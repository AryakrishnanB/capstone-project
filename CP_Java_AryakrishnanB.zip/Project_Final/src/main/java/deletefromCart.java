

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;

class deletefrom
{
	int i=0;
	public void deleteitem(String username,String item)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			
			
			PreparedStatement ps=con.prepareStatement("delete from cart where username='"+username+"' and item='"+item+"' limit 1 ;");
			ps.executeUpdate();
			if(true)
			{
				i=1;
			}
			
		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
}



//@WebServlet("/deletefromCart")
public class deletefromCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		request.getRequestDispatcher("index.html").include(request, response);
		
		
		HttpSession session=request.getSession(false);
		if(session!=null)
		{
			
			String username=(String) session.getAttribute("username");
			deletefrom delete=new deletefrom();

							
			String item=null;
			item=request.getParameter("item");
			
			if(item==null)
			{
				Cookie cookies[]=request.getCookies();
				for(Cookie c:cookies)
				{
					if(c.getName().equals("item"))
					{
						item=c.getValue();
					}
				}
			}
			
			
			
			delete.deleteitem(username, item);
			if(delete.i==1)
			{
//				out.print("Removed from cart...");
				out.print("<html><script>alert('Product has been successfully removed from cart..')</script></html>");
				RequestDispatcher rd=request.getRequestDispatcher("showCart");
				rd.forward(request, response);
			}
			else
			{
				out.print("Error! <br>Please try again...");
				RequestDispatcher rd=request.getRequestDispatcher("showCart");
				rd.forward(request, response);
			}

		}
		else
		{
			out.print("<html><script>alert('Please log in!')</script></html>");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
		
		out.close();
		
		
	}

}
