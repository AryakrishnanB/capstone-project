

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

class cancelfrom
{
	int i=0;
	public void cancelorder(String username,int oid)
	{
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			
			
			PreparedStatement ps=con.prepareStatement("delete from orders where username='"+username+"' and order_id="+oid+";");
			ps.executeUpdate();
			if(true)
			{
				i=1;
			}

		}
			catch(Exception e)
			{
				System.out.println(e);
			}
	}
}


//@WebServlet("/cancelOrderID")
public class cancelOrderID extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		request.getRequestDispatcher("index.html").include(request, response);
		
		HttpSession session=request.getSession(false);
		if(session!=null)
		{
			String username=(String) session.getAttribute("username");
			cancelfrom cancel=new cancelfrom();

			String order_id=null;
			order_id=request.getParameter("oid");
			if(order_id==null)
			{
				Cookie cookies[]=request.getCookies();
				for(Cookie c:cookies)
				{
					if(c.getName().equals("oid"))
					{
						order_id=c.getValue();
					}
				}
			}
			int oid=Integer.parseInt(order_id);
			cancel.cancelorder(username, oid);
			if(cancel.i==1)
			{
//				out.print("Order cancelled...");
				out.print("<html><script>alert('Order has been cancelled..')</script></html>");
				RequestDispatcher rd=request.getRequestDispatcher("showOrders");
				rd.forward(request, response);
			}
			else
			{
				out.print("Error! <br>Please try again...");
				RequestDispatcher rd=request.getRequestDispatcher("showOrders");
				rd.forward(request, response);
			}
						
		}
		
		else
		{
			out.print("<html><script>alert('Please log in!')</script></html>");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
		
		out.close();
		
	}

}
