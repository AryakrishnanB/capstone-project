

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


class confirmRegistration
{
	public boolean check;
	public void insert(String username,String password,String email,long phone)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");	
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
			PreparedStatement ps=con.prepareStatement("insert into users(username,password,email,phone) values(?,?,?,?);");
			ps.setString(1, username);
			ps.setString(2, password);	
			ps.setString(3, email);
			ps.setLong(4, phone);
			
			ps.executeUpdate();
			check=true;
	}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}



//@WebServlet("/registerServlet")
public class registerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		String password=request.getParameter("password");
		String confirmpassword=request.getParameter("confirmpassword");
		String username=request.getParameter("username");
		Long phone=Long.parseLong(request.getParameter("phone"));
		String email=request.getParameter("email");
		PrintWriter out=response.getWriter();
		
		if(password.equals(confirmpassword))
		{
			confirmRegistration confirm=new confirmRegistration();
			confirm.insert(username, confirmpassword, email, phone);
			if(confirm.check==true)
			{
				out.print("<br>Successfully registered....");
//				request.getRequestDispatcher("login.html").include(request, response);
				RequestDispatcher rd=request.getRequestDispatcher("login.html");
				rd.forward(request, response);
			}
		}
			else
			{

//				out.print("<br>Passwords do not match...<br>Please try again..");
				out.print("<html><script>alert('Passwords do not match.Try again!')</script></html>");
				request.getRequestDispatcher("register.html").include(request, response);
				
		}

	}

}
