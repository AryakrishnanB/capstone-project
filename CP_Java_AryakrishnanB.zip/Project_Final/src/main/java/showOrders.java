

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;


//@WebServlet("/showOrders")
public class showOrders extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("*");
		PrintWriter out=response.getWriter();
		
		
		request.getRequestDispatcher("index.html").include(request, response);
		
		HttpSession session=request.getSession(false);
		if(session!=null)
		{
			String username=(String) session.getAttribute("username");
			
			out.print("<home><body><style>"
					+ "button{background-color: cadetblue;border:none;color:white;padding:15px 32px;text-align:center;text-decoration: none;display: inline-block;font-size:15px;}"
					+ "#customers { width: 80%;}"
					+ "#customers td, #customers th {border: 1px solid #ddd;padding: 8px;text-align:center;}"
					+ "#customers tr:hover {background-color: #ddd;}"
					+ "#customers th {padding-top: 12px;padding-bottom: 12px;"
					+ "  text-align: center;background-color: #003366; color: white;}"
					+ "table{align-items:center; font-family:cursive;}"
					+ "</style>");
			
				try {
					
						Class.forName("com.mysql.jdbc.Driver");	
						Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project","root","aryakb@2198ust");
						Statement stmt=con.createStatement();
						
						ResultSet rs=stmt.executeQuery("select  order_id,item,price,quantity,date,totalprice,image,code from orders where username='"+username+"';");
						

					if(rs.next())
					{
						out.print("<center><div  id='main'><table id='customers'>");
						out.print("<tr><th>Order Id</th><th>Product</th><th>Product Code</th><th>Name</th><th>Price</th><th>Quantity</th><th>Date</th><th>TotalPrice</th><th></th></tr>");

						while(rs.next())
					
						{
						int oid=rs.getInt(1);
						String item=rs.getString(2);
						double price=rs.getDouble(3);
						int quantity=rs.getInt(4);
						String date=rs.getString(5);
						double totalprice=rs.getDouble(6);
						String image=rs.getString(7);
						String code=rs.getString(8);
						
						out.print("<tr><td>"+oid+"</td><td><img src='"+image+"' width='100px' height='100px'></td><td>"+code+"</td><td>"+item+"</td><td>"+price+"</td><td>"+quantity+"</td><td>"+date+"</td><td>"+totalprice+"</td><td>"
						
						+"<form action='orderDeleteCookie' method='get'>"
						+ "<input type='hidden' name='oid' value='"+oid+"'/>"
								
						+ "<button type='submit'>Remove</button></form></td></tr>");
					
					}
								
					out.print("</table></div></body></html>");
					}
					else if(!rs.next())
					{
						out.print("<br><br><center>No orders yet....</center>");
					}
					
				} 
				catch (SQLException e) 
				{
					
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
	
		
		else
		{
			out.print("<html><script>alert('Please log in!')</script></html>");
			RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
		
		out.close();
		
		
	}

}
