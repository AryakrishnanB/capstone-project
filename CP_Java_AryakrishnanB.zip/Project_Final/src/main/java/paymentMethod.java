

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class paymentMethod
 */
//@WebServlet("/paymentMethod")
public class paymentMethod extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		request.getRequestDispatcher("index.html").include(request, response);
		String paymethod=request.getParameter("paymentby");
		
		javax.servlet.http.HttpSession session1=request.getSession(false);
		if(session1!=null)
		{
			if(paymethod.equals("Debit/Credit Card"))
			{
				request.getRequestDispatcher("carddetailsform.html").include(request, response);
			}
			
			else if(paymethod.equals("Cash on Delivery"))
			{
//				out.print("<home><script>alert('Order placed successfully...!')</script></html>");
//				javax.servlet.RequestDispatcher rd=request.getRequestDispatcher("showOrders");
//				rd.forward(request, response);
				
				out.print("<html><body><br><br><b><center><img src='https://static.vecteezy.com/system/resources/previews/002/743/514/original/green-check-mark-icon-in-a-circle-free-vector.jpg' width='100px' height='100px'>"
						+ "<br>Order placed successfully...!</b>"
						+ "<br><br><form action='showOrders' method='post'>"
						+ "<button style='background-color: cadetblue;border:none;color:white;padding:15px 32px;text-align:center;text-decoration: none;display: inline-block;font-size:15px;' type='submit'>Show my orders</button></form>"
						+ "</center></body></html>");
			}
		}
		else
		{
			out.print("<home><script>alert('Please log in!')</script></html>");
			javax.servlet.RequestDispatcher rd=request.getRequestDispatcher("login.html");
			rd.forward(request, response);
		}
		
		
	}

}
